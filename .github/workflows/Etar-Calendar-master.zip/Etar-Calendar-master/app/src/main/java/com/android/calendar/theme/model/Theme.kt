package com.android.calendar.theme.model

enum class Theme {
    SYSTEM,
    LIGHT,
    DARK,
    BLACK;
}
