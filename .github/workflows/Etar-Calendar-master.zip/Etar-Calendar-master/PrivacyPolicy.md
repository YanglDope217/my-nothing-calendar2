
# Etar calendar Privacy Policy
Etar is an open source application that respects your privacy. Etar application does not send any of your data to us. Also Etar does not use the Internet permission at all.

### What personal information do we collect from the people that visit our blog, website or app?

Etar does not collect information from the users.

### When do we collect information?

Etar does not collect information from the users.

### How do we use your information?

We do not send your information or use it at all.

### Do we use 'cookies'?

We do not use cookies for tracking purposes.
